export interface IProducts {
    product_id : string;
    product_img : string;
    product_name : string;
    product_price : number;
    product_details : string;
    product_quality : number;
}
